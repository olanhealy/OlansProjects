# Building Websites With HTML, CSS, and JavaScript: Getting Started
Used course on Plural sight to help me build my first proper website.
Changed the way I wanted the website to look and made it my own. 
